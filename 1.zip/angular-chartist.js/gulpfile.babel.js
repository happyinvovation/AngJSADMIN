/*
 * Add tasks to `./gulp/tasks and then import that file into
 * ./gulp/index.js.
 *
 * Add common configuration options to ./gulp/config.js
 */

import './gulp';
